import refresh from "./refresh";

export default function onResize() {
  refresh.call(this);
}
